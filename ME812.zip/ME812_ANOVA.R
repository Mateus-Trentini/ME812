################################################################################
##### Potencial de utilização de fósforo de fontes orgânicas em Eucalyptus ##### 
#####       grandis e E. globulus: influência da micorriza arbuscular      #####
################################################################################
#                                                                              #
# Alunos:                                                                      #
#   Daniela Konno 169494                                                       #
#   Jadson Rodrigo Silva de Oliveira 218405                                    #
#   Maria Julia de Lima Silva 184181                                           #
#   Mateus Trentini 217290                                                     #
#   Matheus Eduardo Baruta Lima 241717                                         #
#                                                                              #
# Professora Supervisora:                                                      #
#   Samara Flamini Kiihl                                                       #
#                                                                              #
# Pesquisadora:                                                                #
#   Sara Adrian Lopez de Andrade                                               #
#                                                                              #
# Colaborador:                                                                 #
#   Leonardo Souza de Andrade                                                  #
#                                                                              #
################################################################################

# Bibliotecas----
library(tidyverse)
library(readxl)
library(here)


# Diretorio----
path <- here() 


# Dados----
dados10 <- read_xlsx(here(path, "Dados.xlsx"), 1)
dados5 <- read_xlsx(here(path, "Dados.xlsx"), 2)


# Fatorial triplo 2 x 7 x 2 com 10 repeticoes----

## Antocianinas
model10_antocianinas <- aov(
  antocianinas ~ Esp * Micorriza * Fonte, 
  data = dados10
)
df <- summary(model10_antocianinas)[[1]][5] %>% 
  data.frame() %>% 
  filter(Pr..F. < 0.05) %>% 
  rownames()

## Clorofila
model10_clorofila <- aov(
  clorofila ~ Esp * Micorriza * Fonte, 
  data = dados10
)
summary(model10_clorofila)

## Flavonois
model10_flavonois <- aov(
  flavonois ~ Esp * Micorriza * Fonte, 
  data = dados10
)
summary(model10_flavonois)

## NBI
model10_nbi <- aov(
  NBI ~ Esp * Micorriza * Fonte, 
  data = dados10
)
summary(model10_nbi)

## Conteudo de potassio (mg) na planta
model10_conteudo <- aov(
  `conteudo de P mg planta -1` ~ Esp * Micorriza * Fonte, 
  data = dados10
)
summary(model10_conteudo)

## Concentracao de potassio (g/kg)
model10_concentracao <- aov(
  `conc P g/kg` ~ Esp * Micorriza * Fonte, 
  data = dados10
)
summary(model10_concentracao)

## PUE
model10_pue <- aov(
  PUE ~ Esp * Micorriza * Fonte, 
  data = dados10
)
summary(model10_pue)

## PUpE
model10_pupe <- aov(
  PUpE ~ Esp * Micorriza * Fonte, 
  data = dados10
)
summary(model10_pupe)

# Fatorial triplo 2 x 7 x 2 com 5 repeticoes----

## Area sup (cm2)
model5_areasup <- aov(
  `area sup (cm2)` ~ Esp * Micorriza * Fonte, 
  data = dados5
)
summary(model5_areasup)

## Diametro medio (mm)
model5_avgdiam <- aov(
  `AvgDiam(mm)` ~ Esp * Micorriza * Fonte, 
  data = dados5
)
summary(model5_avgdiam)

## Comprimento da raiz
model5_rootlength <- aov(
  `root length` ~ Esp * Micorriza * Fonte, 
  data = dados5
)
summary(model5_rootlength)

## Peso da raiz seca (g)
model5_rootdryweight <- aov(
  `root dry weight (g)` ~ Esp * Micorriza * Fonte, 
  data = dados5
)
summary(model5_rootdryweight)

## Peso do broto seco (g)
model5_dryweightshoot <- aov(
  `dry weight shoot (g)` ~ Esp * Micorriza * Fonte, 
  data = dados5
)
summary(model5_dryweightshoot)

## Contagem
model5_countn <- aov(
  `count N` ~ Esp * Micorriza * Fonte, 
  data = dados5
)
summary(model5_countn)

## Fitase
model5_fitase <- aov(
  `Fitase ng Pi/cm2/min` ~ Esp * Micorriza * Fonte, 
  data = dados5
)
summary(model5_fitase)

## rApase
model5_rapase <- aov(
  rApase ~ Esp * Micorriza * Fonte, 
  data = dados5
)
summary(model5_rapase)
